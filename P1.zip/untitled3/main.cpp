#include <iostream>
#include <fstream>
#include <queue>
#include <functional>
#include <random>
#include <math.h>
#include <limits.h>


using namespace std;

const int Event_Count = 100000; // number of events to process
const int NO_CUSTOM = -1;
const int MAX_SIZE = INT_MAX; // maximum buffer size
const double Arrival_Rate = 0.9; // arrival rate in pkts/sec
const double Departure_Rate = 1.0; // departure rate in pkts/sec

// simulation variables
class Event {
private: // will be initialized in this order
    bool type_; // arrival = 1, departure = 0
    double time_; // absolute time when packet arrives/departs from system
public:
    Event(bool type, double time);
    ~Event();
    bool get_type() { return type_; }
    double get_time() const { return time_; } // needs to be const for operator
    void set_type(bool type) { type_ = type; }
    void set_time(double time) { time_ = time; }
    inline bool operator > (const Event& rhs) const { return time_ > rhs.get_time(); }
    string details();
};

Event::Event (bool type, double time) : type_(type), time_(time) {}
Event::~Event () {}
string Event::details () {
    string s = "Event(";
    s += to_string(type_);
    s += ", ";
    s += to_string(time_);
    s += ")";
    return s;
}

class Packet {
private:
    double service_time_; // intrinsic service time
public:
    Packet (double st);
    ~Packet ();
    double get_service_time () { return service_time_; }
    string details ();
};

Packet::Packet (double st) : service_time_(st) {}
Packet::~Packet () {}
string Packet::details () {
    string s = "Packet(";
    s += to_string(service_time_);
    s += ")";
    return s;
}




double g_time; // absolute system time
int g_length; // total number of packets in system (buffer + server)
priority_queue<Event, vector<Event>, greater<Event>> gel; // global event list
queue<Packet> buffer; // queue for link processor

// statistical variables

double g_queue_length_sum; // sum of queue lengths
double g_free_time_sum;
int g_pkts_dropped;
double g_time_difference;

double negative_exponential (double rate) {
    mt19937 rng;
    rng.seed(random_device()());
    uniform_real_distribution<double> distribution(0.0, 1.0);
    double u = distribution(rng);
    return (((-1 / rate) * log(1 - u)));
}

void advance_system_time (Event e) {
    double old = g_time;
    g_time = e.get_time();
    g_time_difference = g_time - old;
    cout << "Advancing time from ";
    cout << old << " to " << g_time << endl;
}

Event generate_event (bool type, double custom) {
    double ist; // intrinsic service time
    if (custom != NO_CUSTOM) { ist = custom; } // user-defined ist
    else { ist = type ? negative_exponential(Arrival_Rate) : negative_exponential(Departure_Rate); }
    Event e(type, g_time + ist);
    cout << "New event: " << e.details() << endl;
    return e;
}

void init (ofstream& fs) {
    cout << "Initializing" << endl;
    g_time = 0.0, g_length = 0, g_queue_length_sum = 0.0,
    g_free_time_sum = 0.0, g_pkts_dropped = 0, g_time_difference = 0;
    Event first = generate_event(1, NO_CUSTOM); // generate first arrival event
    gel.push(first); // push first arrival event to start simulation
    cout << "Done initializing" << "\n\n";
    fs << "Arrival_Rate" << ",";
    fs << "Utilization" << ",";
    fs << "Mean queue length" << endl;
}

void process_arrival_event (Event a) {
    advance_system_time(a);  //update global timer
    Packet packet(negative_exponential(Departure_Rate)); // create new packet

    Event next_arrival = generate_event(1, NO_CUSTOM);
    gel.push(next_arrival);

    if (g_length == 0) { // server free
        cout << "Server free, will now process this packet" << endl;
        g_free_time_sum += g_time_difference; // record server free time
        Event depart_event = generate_event(0, packet.get_service_time());
        gel.push(depart_event);
        g_length = 1; // 1 packet in system, being processed in server
    }
    else if (g_length > 0) { // server busy
        cout << "Server busy. ";
        if (g_length - 1 < MAX_SIZE) { // buffer not full
            cout << "Buffer NOT full, queuing packet" << endl;
            buffer.push(packet);
            g_length++; // 1 more packet in system (in buffer)
        }
        else { // buffer full
            cout << "Buffer full, dropping packet" << endl;
            g_pkts_dropped++;
        }
    }
}

void process_departure_event (Event d) {
    advance_system_time(d);
    g_length--; // packet is out of system now
    cout << "Server done processing packet" << endl;
    if (g_length > 0) { // buffer not empty
        cout << "Buffer NOT empty, processing next packet" << endl;
        Packet packet = buffer.front();
        buffer.pop(); // dequeue packet
        Event depart_event = generate_event(0, packet.get_service_time());
        gel.push(depart_event);
    }
    else { //  empty
        cout << "Buffer empty, taking no action" << endl;
    }
}

void update_statistics () {
    cout << "Total server free time: " << g_free_time_sum << endl;
    cout << "Updating statistics" << "\n\n";
    g_queue_length_sum += buffer.size() * g_time_difference;
}

void output_statistics (ofstream& fs) {
    cout << "----------" << endl;
    cout << "Statistics" << endl;
    cout << "----------" << endl;
    cout << "Total_queue_length: " << g_queue_length_sum << endl;
    cout << "Total_server_busy_time: " << (g_time - g_free_time_sum) << endl;
    cout << "Total_simulation_time: " << g_time << endl;
    cout << "Utilization: " << ((double) ((g_time - g_free_time_sum)) / (double) g_time) << endl;
    cout << "Average_queue_length: " << ((double) g_queue_length_sum / (double) g_time) << endl;
    cout << "Number_dropped: " << g_pkts_dropped << endl;
    fs << Arrival_Rate << ",";
    fs << ((double) (g_time - g_free_time_sum) / (double) g_time) << ",";
    fs << ((double) g_queue_length_sum / (double) g_time) << endl;
}

int main (int argc, char* argv[]) {
    ofstream fs("output.csv");
    if (!fs) {
        cerr << "Cannot open file" << endl;
        return 1;
    }
    init(fs);
    for (int i = 0; i < Event_Count; i++) {
        Event e = gel.top();
        cout << "Processing " << e.details() << endl;
        gel.pop();
        if (e.get_type() == 1) { process_arrival_event(e); }
        else { process_departure_event(e); }
        cout << "buffer.size(): " << buffer.size() << endl;
        cout << "g_length: " << g_length << endl;
        update_statistics();
    }
    output_statistics(fs);
    fs.close();
    return 0;
}
